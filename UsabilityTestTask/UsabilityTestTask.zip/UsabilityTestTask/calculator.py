def safe_divide(a, b):
    """
    Returns a / b rounded to 2 decimal places.
    Returns "Error" if b is 0.
    """
    pass
